# Kaggle: результаты baseline и hierarchical paper-DAR

Проверено UTC: 2026-10-16T14:12:22.633773+00:00

## Итог

| Модель | Seed | Параметры | Шаги | Train tokens | Val CE | PPL | bpb (оценка) |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | 1 | 334,156,800 | 65,000 | 4,259,840,000 | 2.923157 | 18.5999 | 1.004101 |
| baseline | 2 | 334,156,800 | 65,000 | 4,259,840,000 | 2.922353 | 18.5850 | 1.003825 |
| paper-DAR hybrid | 1 | 307,131,392 | 62,673 | 4,107,337,728 | 2.892107 | 18.0313 | 0.993435 |
| paper-DAR hybrid | 2 | 307,131,392 | 62,683 | 4,107,993,088 | 2.891383 | 18.0182 | 0.993187 |

Средний CE baseline=2.922755; paper-DAR=2.891745; delta=-0.031010 nats/token. Изменение геометрического среднего PPL: -3.053%. Paper-DAR hybrid лучше baseline в обоих seeds при общем лимите 8ч54м.

## Проверка исполнения

- Все 4 notebook COMPLETE, есть SUCCESS.json и ненулевое число обновлений; skipped_steps=0. Все записанные train loss/grad_norm конечны; runtime preflight подтвердил 8 TPU и finite forward/backward.
- Все остановлены wall_time_budget. Один полный проход данных НЕ завершён; train содержит 9,035,582,489 tokens.
- Все локальные проверки артефактов прошли: True. Проверяются hashes скачанных source-файлов относительно manifest и ожидаемый immutable commit.
- Время hours в SUCCESS — внутреннее время trainer. Полное notebook время ниже 32040 секунд по последнему timestamp Kaggle log; очередь в этот лимит не включается.

| Аккаунт | Версия | Commit | Последний timestamp notebook, с | DAR gradient preflight |
|---|---:|---|---:|---:|
| 2 | 2 | `bf80e315732837c4261f32faebbb052c51dee094` | 31565.2 | 0.0 |
| 3 | 2 | `bf80e315732837c4261f32faebbb052c51dee094` | 31474.9 | 0.0 |
| 4 | 3 | `697a10d3cf06be5a5b9cafa38fe272629814e64f` | 31710.5 | 0.0004397462762426585 |
| 5 | 3 | `697a10d3cf06be5a5b9cafa38fe272629814e64f` | 31683.0 | 0.0004397462762426585 |

## Сопоставимость и границы вывода

- Общие batch=32, seq_len=2048, датасет, tokenizer, validation windows, seed_data по паре, правило optimizer и wall-time LR. Dataset edge hashes проверяются в provenance. Paper-модель 307.13M, baseline 334.16M; это не сравнение с одинаковым числом параметров или FLOPs.
- Финальная validation: 4,390,912 target tokens, 67 полных batches из val.bin. Остаток неполного batch отброшен. eval_batches=100 превышает доступные 67, поэтому промежуточная validation фактически использует те же окна, что и финальная.
- PPL=exp(CE) на GPT-2 токенах. bpb является оценкой с bytes_per_token=4.2. Отдельный отложенный test и внешние downstream benchmark не выполнялись.
- Это преимущество hybrid с paper-DAR над pure GDN2 baseline, а не изолированная польза DAR и не сравнение paper-DAR с нашей прежней hybrid-версией. Одновременно отличаются MLA и routing.
- Два seed дают повторяемый знак в этих прогонах, но недостаточны для широких выводов. В matched-token точке LR-траектории различны из-за расписания по wall time.

| Seed | Общий шаг | Tokens | Baseline CE | Paper CE | Delta |
|---|---:|---:|---:|---:|---:|
| 1 | 61500 | 4,030,464,000 | 2.928888 | 2.893507 | -0.035381 |
| 2 | 61500 | 4,030,464,000 | 2.927953 | 2.893050 | -0.034903 |

## Сохранения и извлечение

- В outputs/<run>/<run>/runs/<run>/ скачаны SUCCESS.json, metrics.jsonl, config.yaml, provenance.json, runtime-preflight.json; также training.log, pip-freeze, исходники и checkpoint metadata.
- Финальные checkpoints опубликованы на Kaggle: baseline шаг 65000; paper шаги 62673/62683. Есть commit_success markers и OCDBT binary entries в inventory. Полные веса/optimizer state локально не скачаны; восстановление checkpoint в этом аудите не проверялось.
- В логах есть долгие ожидания сохранений около 200–243 секунд. Они не сорвали завершение, но их стоит сократить при следующем эксперименте. Текущие результаты от этого не переобучались.
- JSON: reports/kaggle-final-results.json; CSV: reports/kaggle-final-results.csv; списки remote файлов: reports/inventory-{2..5}.json.
- Ошибка Windows charmap при первом скачивании исправлена повторным запуском клиента с -X utf8. Все четыре output receipt теперь ok=true. Аккаунт 1 не использован.
