# Atomic-GDN2: все 4 прогона, 16 октября 2026

Этот архив содержит все скачанные логи, метрики и текстовые артефакты четырёх завершённых Kaggle запусков.
Аккаунты 2/3: baseline seeds 1/2, версия 2. Аккаунты 4/5: hierarchical paper-DAR hybrid seeds 1/2, версия 3.

Начать с tables/bpb-results.md или tables/kaggle-bpb-all-logs.xlsx.
Все числовые таблицы также находятся в tables/*.csv (UTF-8 с BOM).
tables/tables.json содержит те же таблицы и SHA256 исходных трёх журналов каждого прогона.
kaggle-final-results.md содержит проверку исполнения и ограничения сравнения.
evidence/kaggle-final-results.json содержит точные итоги, все validation значения,
конфигурации, hashes, результаты проверок и список опубликованных checkpoint-файлов.

Состав таблиц:
- Итоги: все 4 запуска и финальный/best validation bpb.
- Val по шагам: 46 точек объединённой истории. Пусто = записи нет, интерполяции нет.
- Validation: все 172 записи.
- Train: все 5106 записей, обычно каждые 50 шагов, со всеми числовыми полями.
- События: все 8 start/done records.
- Console: все 6836 записей консоли с notebook-relative seconds и stdout/stderr.
- Training log: все 5444 строки четырёх training.log.

В raw/<run>/ находятся оригиналы metrics.jsonl, training.log, полный Kaggle console log,
SUCCESS.json, provenance.json, runtime-preflight.json, config.yaml, pip-freeze.txt,
скачанные исходники и checkpoint metadata/commit markers.
Содержание Console и training.log частично повторяется, обе исходные версии сохранены.
Незаписанные optimizer steps не восстановлены.

Время:
- run-times.json содержит UTC и Europe/Moscow (+03:00), внутреннее trainer time,
  длительность от runtime preflight до done и последний относительный timestamp notebook.
- Точные timestamps каждой метрики находятся в metrics.jsonl и CSV.
- Время ожидания TPU в очереди не является временем обучения.
- Все прогоны остановились по бюджету 32040 секунд, включая setup/compile и финализацию.

bpb est = token CE / ln(2) / 4.2. Это оценка при 4.2 bytes/token, не точный byte-level bpb.
Train bpb относится к отдельному записанному minibatch. Validation использует 4,390,912 target tokens.
Periodic flag сохранён: доступно 67 batches, eval_batches=100, поэтому periodic и final
validation используют одинаковые доступные окна. Полный train pass не завершён.
Средний final bpb: baseline 1.003962857, paper hybrid 0.993310912.
Delta paper − baseline = -0.010651945 bpb (-1.061%).
Это сравнение hybrid и baseline целиком, не изолированный эффект DAR или сравнение со старым hybrid.

Excel представляет запрещённые XML управляющие символы как буквальные hex escapes.
Оригинальный текст, точные времена и все поля сохранены в raw и CSV/JSON.

Полные бинарные веса и optimizer state в этот архив НЕ включены.
Их наличие в Kaggle подтверждено inventory и commit markers, локальный restore не выполнялся.
Архив предназначен для передачи результатов и анализа без доступа к секретам.
В manifest.json перечислены файлы, размеры и SHA256.
