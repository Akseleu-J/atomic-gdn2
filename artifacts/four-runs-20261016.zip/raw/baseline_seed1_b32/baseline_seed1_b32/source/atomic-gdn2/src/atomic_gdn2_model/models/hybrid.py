"""Hybrid GDN-2 / MLA language model with hierarchical block-delta DAR (v11 of the research code).

Per block of `layers_per_block` token-mixing layers (default 3x GDN-2 + 1x MLA) followed by one
SwiGLU.  Each layer's input is an attention-weighted mix of [block_input, delta_1..delta_{i-1}]
(`IntraBlockAttention`); each layer's output is a *delta* added to the residual stream.

The retrieved cross-block/local-delta mixture is added to the intra-block mixture before RMSNorm.
This makes retrieval influence the sublayer input and receive task gradients. This corrected
architecture is a new experiment and is not equivalent to the original v11 checkpoints.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
from flax import linen as nn

from ..config import ModelConfig
from .common import SwiGLU
from .gdn2 import GDN2Sub
from .mla import MLASub


def _sanitize(x, lim=1e3):
    return jnp.nan_to_num(jnp.clip(x, -lim, lim), nan=0.0, posinf=lim, neginf=-lim)


class IntraBlockAttention(nn.Module):
    """Attention over [block_input, delta_1, ..., delta_i] with q = block_input."""
    cfg: ModelConfig

    @nn.compact
    def __call__(self, sources, block_input):
        if len(sources) <= 1:
            return sources[0]
        dl, cd, pd = self.cfg.d_latent, self.cfg.cdtype, self.cfg.pdtype
        q = nn.Dense(dl, use_bias=False, name="q_proj", dtype=cd, param_dtype=pd)(block_input)
        k = jnp.stack([nn.Dense(dl, use_bias=False, name=f"k_proj_{i}", dtype=cd, param_dtype=pd)(s)
                       for i, s in enumerate(sources)], axis=0)
        scores = jnp.einsum("bld,nbld->nbl", q, k) / jnp.sqrt(jnp.array(dl, dtype=jnp.float32))
        weights = jax.nn.softmax(scores, axis=0)
        mixed = jnp.einsum("nbl,nbld->bld", weights, jnp.stack(sources, axis=0))
        return mixed.astype(block_input.dtype)


class HybridDARAttention(nn.Module):
    """Attention over [block_summaries..., local_deltas...] with q = current_x."""
    cfg: ModelConfig

    @nn.compact
    def __call__(self, current_x, all_sources):
        n = len(all_sources)
        if n == 0:
            return jnp.zeros_like(current_x)
        if n == 1:
            return all_sources[0].astype(current_x.dtype)
        dl, cd, pd = self.cfg.d_latent, self.cfg.cdtype, self.cfg.pdtype
        stack = jnp.stack(all_sources, axis=0)
        n_s, b, l, d = stack.shape
        k = nn.Dense(dl, use_bias=False, name="k_proj", dtype=cd, param_dtype=pd)(
            stack.reshape(n_s * b * l, d)).reshape(n_s, b, l, dl)
        q = nn.Dense(dl, use_bias=False, name="q_proj", dtype=cd, param_dtype=pd)(current_x)
        scores = jnp.einsum("bld,nbld->nbl", q, k) / jnp.sqrt(jnp.array(dl, dtype=jnp.float32))
        weights = jax.nn.softmax(scores, axis=0)
        return jnp.einsum("nbl,nbld->bld", weights, stack).astype(current_x.dtype)


class BlockDARLayer(nn.Module):
    cfg: ModelConfig
    layer_type: str
    deterministic: bool = False

    @nn.compact
    def __call__(self, current_x, block_input, local_deltas, history_blocks):
        dar_sources = [history_blocks[j] for j in range(history_blocks.shape[0])] + list(local_deltas)
        retrieved = HybridDARAttention(self.cfg, name="dar")(current_x, dar_sources)

        intra_sources = [block_input] + list(local_deltas)
        mixed = IntraBlockAttention(self.cfg, name="intra")(intra_sources, block_input)
        mixed = mixed + retrieved
        mixed = nn.RMSNorm(epsilon=1e-6, name="pre_sublayer_norm")(mixed)

        sub = GDN2Sub if self.layer_type == "gdn2" else MLASub
        delta = sub(self.cfg, self.deterministic, name="sublayer")(mixed)
        return _sanitize(delta)


class BlockDAR(nn.Module):
    cfg: ModelConfig
    block_idx: int
    deterministic: bool = False

    @nn.compact
    def __call__(self, current_x, history_blocks):
        c = self.cfg
        block_input, local_deltas = current_x, []
        types = c.layer_types
        start = self.block_idx * c.layers_per_block
        for i in range(c.layers_per_block):
            li = start + i
            lt = types[li] if li < len(types) else types[-1]
            delta = BlockDARLayer(c, lt, self.deterministic, name=f"layer_{i}")(
                current_x, block_input, local_deltas, history_blocks)
            local_deltas.append(delta)
            current_x = _sanitize(current_x + delta)

        h = nn.LayerNorm(dtype=c.cdtype, param_dtype=c.pdtype)(current_x)
        current_x = current_x + SwiGLU(c, self.deterministic, name="ffn")(h)

        block_delta = local_deltas[0]
        for d in local_deltas[1:]:
            block_delta = block_delta + d
        return current_x, jnp.concatenate([history_blocks, block_delta[None, ...]], axis=0)


class LM(nn.Module):
    cfg: ModelConfig
    deterministic: bool = False

    @nn.compact
    def __call__(self, ids):
        c = self.cfg
        cd, pd = c.cdtype, c.pdtype
        emb = nn.Embed(c.vocab_size, c.d_model, embedding_init=nn.initializers.normal(0.02),
                       dtype=cd, param_dtype=pd)
        x = emb(ids)
        n_blocks = (len(c.layer_types) + c.layers_per_block - 1) // c.layers_per_block
        history = jnp.zeros((0,) + x.shape, dtype=x.dtype)
        for i in range(n_blocks):
            x, history = nn.remat(BlockDAR)(c, i, self.deterministic, name=f"block_{i}")(x, history)
        x = nn.LayerNorm(dtype=cd, param_dtype=pd)(x)
        x32 = x.astype(jnp.float32)
        if c.tie_embeddings:
            return jnp.dot(x32, emb.embedding.astype(jnp.float32).T)
        return nn.Dense(c.vocab_size, use_bias=False, kernel_init=nn.initializers.normal(0.02),
                        dtype=jnp.float32, param_dtype=pd)(x32)
